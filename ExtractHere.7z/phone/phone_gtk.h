void gtkphone_backend_init(void);
void write_typed_text(char *text);
