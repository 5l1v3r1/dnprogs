typedef int (*fd_callback) (int);
