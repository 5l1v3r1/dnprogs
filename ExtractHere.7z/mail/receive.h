void receive_mail(int);
