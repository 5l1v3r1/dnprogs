#define APPEND_UNDERSCORE
#include "to_vax_d8.c"
