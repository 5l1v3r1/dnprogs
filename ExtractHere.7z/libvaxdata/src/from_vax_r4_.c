#define APPEND_UNDERSCORE
#include "from_vax_r4.c"
