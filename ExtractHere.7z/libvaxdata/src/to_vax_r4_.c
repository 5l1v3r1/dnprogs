#define APPEND_UNDERSCORE
#include "to_vax_r4.c"
