#define APPEND_UNDERSCORE
#include "from_vax_h16.c"
