#if defined( __VMS ) && defined( __DECC )
#pragma module to_vax_g8
#endif
#define MAKE_TO_VAX_G8
#include "convert_vax_data.c"
