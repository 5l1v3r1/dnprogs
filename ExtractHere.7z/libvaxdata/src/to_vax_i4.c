#if defined( __VMS ) && defined( __DECC )
#pragma module to_vax_i4
#endif
#define MAKE_TO_VAX_I4
#include "convert_vax_data.c"
