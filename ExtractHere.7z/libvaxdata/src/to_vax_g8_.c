#define APPEND_UNDERSCORE
#include "to_vax_g8.c"
