#define APPEND_UNDERSCORE
#include "to_vax_i4.c"
