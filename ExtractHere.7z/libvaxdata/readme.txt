See the accompanying USGS Open-File Report 2005-1424, v1.2, libvaxdata: VAX Data
Format Conversion Routines, for a description of the libvaxdata routines, with
sample C and Fortran code and compilation instructions.  There is a readme.txt
file with compilation and link instructions for each platform that has been
tested, in a directory named for the platform (linux, macosx, tru64, vms, and
win32).

Lawrence M. Baker
US Geological Survey
baker@usgs.gov
November 22, 2005
Updated February 2, 2010 (v1.1)
Updated April 15, 2010 (v1.2)
