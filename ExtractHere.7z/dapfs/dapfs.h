#define VMSNAME_LEN 2048
#define BUFLEN      1024
