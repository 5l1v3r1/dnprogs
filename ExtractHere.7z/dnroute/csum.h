extern unsigned short route_csum(unsigned char *buf, int start, int end);
